
local OD = Config.EnableOverdose
local kd = Config.EnableKillDrugsCommand

local weedDuration = Config.WeedEffectDuration
local cokeDuration = Config.CokeEffectDuration
local methDuration = Config.MethEffectDuration
local LeanDuration = Config.LeanEffectDuration
local N2ODuraation = Config.N2OEffectDuration

--START OF CODE
high = false 
DisabledRun = false

Citizen.CreateThread(function()
		Citizen.Wait(0)
		if DisabledRun == true then
			DisableControlAction(0,21,true)
		end
end)

Citizen.CreateThread(function()
	while true do
		if IsPlayerDead(PlayerId()) then
			if high then 
       			 StopGameplayCamShaking(true)
				resetAnims()
				DisabledRun = false
				high = false
				SetTransitionTimecycleModifier('default', 0.35)
				--SetPedMoveRateOverride(source, 0)
				SetRunSprintMultiplierForPlayer(source, 1.01)
				SetEntityMaxHealth(GetPlayerPed(-1), 200)
				TriggerEvent('chat:addMessage', {
					color = { 255, 0, 0},
					multiline = true,
					args = {"Jm Drugs", "^2^*You have died under the influence"}
				})
			end
		end
		Citizen.Wait(3500)
    end
end)


RegisterCommand("drugs-weed", function(source, args, rawCommand)
	if #args < 1 then
		-- Too low args
		TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0 },
			multiline = true,
			args = { "Jm Drugs", "^2Correct usage of command is ^*/weed <amount>" }
		})
		return
	end

	local playerPed = PlayerPedId()
	local packageHash = GetHashKey("hei_prop_hei_drug_case", "prop_weed_block_01", "prop_weed_02", "prop_weed_01", "hei_prop_heist_weed_pallet_02")
	local packageNearby = DoesObjectOfTypeExistAtCoords(GetEntityCoords(playerPed), 1.0, packageHash, false)

	if not packageNearby then
		TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0 },
			multiline = true,
			args = { "Jm Drugs", "^2^*No drugs nearby to use" }
		})
		return
	end

	if high == false then
		local amount = tonumber(args[1])
		TriggerEvent('chat:addMessage', {
			color = { 0, 0, 255 },
			multiline = true,
			args = { "^2You have smoked " .. amount .. " gram's of weed" }
		})
		ShakeGameplayCam('DRUNK_SHAKE', 0.35)
		SetPedMotionBlur(playerPed, true)

		-- Play the smoking animation for 3 seconds
		TaskStartScenarioInPlace(playerPed, "WORLD_HUMAN_SMOKING_POT", 0, false)
		Citizen.Wait(3000) -- Wait for 3 seconds

		-- Stop the smoking animation
		ClearPedTasks(playerPed)

		local FadeTime = (Config.WeedEffectDuration / 10) -- Use Config option for duration
		high = true
		SetTimecycleModifier('BloomMid')
		Citizen.Wait(Config.WeedEffectDuration * amount - 3000) -- Use Config option for duration and wait for the remaining duration
		high = false
		StopGameplayCamShaking(true)
		resetAnims()
		SetPedMotionBlur(playerPed, false)
		SetTransitionTimecycleModifier('default', 0.35)
	else
		TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0 },
			multiline = true,
			args = { "Jm Drugs", "^2^*You are already high" }
		})
	end
end)

function IsNearProps(playerPed, props)
	for _, prop in pairs(props) do
		local propFound = false
		local propCoords = GetEntityCoords(playerPed)
		local objects = GetGamePool("CObject")

		for i = 1, #objects, 1 do
			local obj = objects[i]
			local objCoords = GetEntityCoords(obj)

			if GetEntityModel(obj) == GetHashKey(prop) and Vdist(propCoords.x, propCoords.y, propCoords.z, objCoords.x, objCoords.y, objCoords.z) < 10.0 then
				propFound = true
				break
			end
		end

		if propFound then
			return true
		end
	end

	return false
end

RegisterCommand("drugs-coke", function(source, args, rawCommand)
	if #args < 1 then
		-- Too low args
		TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0 },
			multiline = true,
			args = { "Jm Drugs", "^2Correct usage of the command is ^*/coke <amount>" }
		})
		return
	end

	local playerPed = PlayerPedId()
	local packageHash = GetHashKey("hei_prop_hei_drug_pack_01b")
	local packageNearby = DoesObjectOfTypeExistAtCoords(GetEntityCoords(playerPed), 1.0, packageHash, false)

	if not packageNearby then
		TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0 },
			multiline = true,
			args = { "Jm Drugs", "^2^*No cocaine package nearby" }
		})
		return
	end

	if high == false then
		local amount = tonumber(args[1])
		TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0 },
			multiline = true,
			args = { "Jm Drugs", "^2You have snorted " .. amount .. " gram(s) of coke" }
		})
		-- DRUG EFFECTS START HERE
		ShakeGameplayCam('SKY_DIVING_SHAKE', 0.95)
		SetPedMotionBlur(GetPlayerPed(-1), true)
		runAnim("move_m@drunk@moderatedrunk")
		local FadeTime = (Config.CokeEffectDuration / 10) -- Use Config option for duration
		SetPedMoveRateOverride(source, 5.0)
		SetRunSprintMultiplierForPlayer(source, 1.49)
		high = true
		SetTimecycleModifier('Bloom')
		--Coming Down
		DisabledRun = true
		Citizen.Wait(Config.CokeEffectDuration * amount) -- Use Config option for duration
		SetRunSprintMultiplierForPlayer(source, 1.01)
		--SetPedMoveRateOverride(source, 0)
		runAnim("move_m@drunk@moderatedrunk")
		Citizen.Wait(15000)
		local r = math.random(1, 30)
		if r == 1 then
			SetEntityHealth(PlayerPedId(), 0)
			TriggerEvent('chat:addMessage', {
				color = { 255, 0, 0 },
				multiline = true,
				args = { "Jm Drugs", "^2^*Your body did not react well with the cocaine, and you died" }
			})
		end
		--ENDING THE HIGH
		DisabledRun = false
		high = false
		StopGameplayCamShaking(true)
		resetAnims()
		SetPedMotionBlur(GetPlayerPed(-1), false)
		SetTransitionTimecycleModifier('default', 0.35)
		-- OVERDOSE
		if amount == 2 or (amount > 2 and OD == true) then
			SetEntityHealth(PlayerPedId(), 0)
			TriggerEvent('chat:addMessage', {
				color = { 255, 0, 0 },
				multiline = true,
				args = { "Jm Drugs", "^2^*You have died from an overdose" }
			})
		end
	else
		TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0 },
			multiline = true,
			args = { "Jm Drugs", "^2^*You are already high" }
		})
	end
end)

RegisterCommand("drugs-lean", function(source, args, rawCommand)
	if #args < 1 then
	    -- Too low args
	    TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0},
			multiline = true,
			args = {"Jm Drugs", "^2Correct usage of command is ^*/lean <amount>"}
		})
	    return;
	end
	if high == false then
		local amount = tonumber(args[1])
		TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0},
			multiline = true,
			args = {"Jm Drugs", "^2You have drank ".. amount.." doublecup(s) (500ml each) of lean"}
		})
		-- DRUG EFFECTS START HERE
		ShakeGameplayCam('DRUNK_SHAKE', 4.95)
		SetPedMotionBlur(GetPlayerPed(-1), true)
		runAnim("MOVE_M@DRUNK@SLIGHTLYDRUNK")
		high = true
		SetTimecycleModifier('BlackOut')
		--Coming Down
		DisabledRun = true
		Citizen.Wait(JmanLeanDura*amount)
		if amount == 0.5 or amount > 0.5 then
			SetPedToRagdoll(GetPlayerPed(-1), 7500, 7500, 0, 0, 0, 0)
			TriggerEvent('chat:addMessage', {
				color = { 255, 0, 0},
				multiline = true,
				args = {"Jm Drugs", "^2You were very tired from the lean and fell asleep"}
			})
			Citizen.Wait(7500)
		end
		--ENDING THE HIGH
		DisabledRun = false
		high = false
		StopGameplayCamShaking(true)
		resetAnims()
		SetPedMotionBlur(GetPlayerPed(-1), false)
		SetTransitionTimecycleModifier('default', 0.35)
		-- OVERDOSE
		if amount == 4 or amount > 4 and OD == true then
			SetEntityHealth(PlayerPedId(), 0)
			TriggerEvent('chat:addMessage', {
				color = { 255, 0, 0},
				multiline = true,
				args = {"Jm Drugs", "^2^*You have died to an overdose"}
			})
		end
	else 
	TriggerEvent('chat:addMessage', {
		color = { 255, 0, 0},
		multiline = true,
		args = {"Jm Drugs", "^2^*You are already high"}
	})
	end
end)

RegisterCommand("drugs-meth", function(source, args, rawCommand)  --- Meth Consumabale
	if #args < 1 then
	    -- Too low args
	    TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0},
			multiline = true,
			args = {"Jm Drugs", "^2Correct usage of command is ^*/meth <amount>"}
		})
	    return;
	end
	if high == false then
		local amount = tonumber(args[1])
		TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0},
			multiline = true,
			args = {"Jm Drugs", "^2You have injected ".. amount.." syringe(s) of meth"}
		})
		-- DRUG EFFECTS START HERE
		ShakeGameplayCam('DRUNK_SHAKE', 0.65)
		SetPedMotionBlur(GetPlayerPed(-1), true)
		runAnim("MOVE_M@DRUNK@MODERATEDRUNK_HEAD_UP")
		--FOR TESTING
		Citizen.Wait(3)
		--END
		SetEntityHealth(GetPlayerPed(-1), 200)
		high = true
		SetTimecycleModifier('BeastIntro01')
		--Coming Down
		Citizen.Wait(JmanMethDura*amount)
		SetEntityHealth(GetPlayerPed(-1), 110)
		local r = math.random(1,20)
		if r == 1 then
			SetEntityHealth(PlayerPedId(), 0)
			TriggerEvent('chat:addMessage', {
				color = { 255, 0, 0},
				multiline = true,
				args = {"Jm Drugs", "^2^*Your body did not react well with the meth and you died"}
			})	
		end
		--ENDING THE HIGH
		high = false
		StopGameplayCamShaking(true)
		resetAnims()
		SetPedMotionBlur(GetPlayerPed(-1), false)
		SetTransitionTimecycleModifier('default', 0.35)
		-- OVERDOSE
		if amount == 3 or amount > 3 and OD == true then
			SetEntityHealth(PlayerPedId(), 0)
			TriggerEvent('chat:addMessage', {
				color = { 255, 0, 0},
				multiline = true,
				args = {"Jm Drugs", "^2^*You have died to an overdose"}
			})
		end
	else 
	TriggerEvent('chat:addMessage', {
		color = { 255, 0, 0},
		multiline = true,
		args = {"Jm Drugs", "^2^*You are already high"}
	})
	end
end)

RegisterCommand("drugs-N2O", function(source, args, rawCommand) ---- Currently there is some issues with the N20 drug (Nangs)
	if #args < 1 then
	    -- Too low args
	    TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0},
			multiline = true,
			args = {"Jm Drugs", "^2Correct usage of command is ^*/N2O <amount>"}
		})
	    return;
	end
	if high == false then
		local amount = tonumber(args[1])
		TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0},
			multiline = true,
			args = {"Jm Drugs", "^2You have sucked in ".. amount.." canister(s) of N2O"} ---- Currently there is some issues with the N20 drug (Nangs)
		})
		-- DRUG EFFECTS START HERE
		ShakeGameplayCam('DRUNK_SHAKE', 90.95)
		SetPedMotionBlur(GetPlayerPed(-1), true)
		runAnim("MOVE_M@DRUNK@SLIGHTLYDRUNK")
		high = true
		SetTimecycleModifier('BarryFadeOut')
		--Coming Down
		DisabledRun = true
		Citizen.Wait(JmanN2ODura*amount)
		if amount == 1 or amount > 1 then
			SetPedToRagdoll(GetPlayerPed(-1), 7500, 7500, 0, 0, 0, 0)
			TriggerEvent('chat:addMessage', {
				color = { 255, 0, 0},
				multiline = true,
				args = {"Jm Drugs", "^2You passed out from the N2O"} --- Overdose
			})
			Citizen.Wait(7500)
		end
		local r = math.random(1,50)
		if r == 1 then
			SetEntityHealth(PlayerPedId(), 0)
			TriggerEvent('chat:addMessage', {
				color = { 255, 0, 0},
				multiline = true,
				args = {"Jm Drugs", "^2^*Your body did not react well with the N2O and you died"}
			})	
		end
		--ENDING THE HIGH
		DisabledRun = false
		high = false
		StopGameplayCamShaking(true)
		resetAnims()
		SetPedMotionBlur(GetPlayerPed(-1), false)
		SetTransitionTimecycleModifier('default', 0.35)
		-- OVERDOSE
		if amount == 5 or amount > 5 and OD == true then
			SetEntityHealth(PlayerPedId(), 0)
			TriggerEvent('chat:addMessage', {
				color = { 255, 0, 0},
				multiline = true,
				args = {"Jm Drugs", "^2^*You have died to an overdose"} 
			})
		end
	else 
	TriggerEvent('chat:addMessage', {
		color = { 255, 0, 0},
		multiline = true,
		args = {"Jm Drugs", "^2^*You are already high"}
	})
	end
end)

RegisterCommand("killhigh", function(source, args, rawCommand) --- Killhigh command 
	if kd == true then
		high = false
		StopGameplayCamShaking(true)
		resetAnims()
		SetTransitionTimecycleModifier('default', 0.35)
		--SetPedMoveRateOverride(source, 0)
		SetRunSprintMultiplierForPlayer(source, 1.01)
		SetEntityMaxHealth(GetPlayerPed(-1), 200)
		TriggerEvent('chat:addMessage', {
			color = { 255, 0, 0},
			multiline = true,
			args = {"Jm Drugs", "^2Drugs have been removed from your body"} --- Chat message for kill high command 
		})
	else
	TriggerEvent('chat:addMessage', {
		color = { 255, 0, 0},
		multiline = true,
		args = {"Jm Drugs", "^2^*Kill drugs has been disabled on this server"} 
	})
	end
end)


ocal drinkingBeer = false

RegisterCommand("drugs-beer", function(source, args, rawCommand)
    if not drinkingBeer then
        drinkingBeer = true
        local playerPed = GetPlayerPed(-1)

        local beerModel = GetHashKey("prop_ld_beer")
        local beerAnimDict = "mp_player_intdrink"
        local beerAnimName = "loop_bottle"

        RequestModel(beerModel)
        while not HasModelLoaded(beerModel) do
            Citizen.Wait(0)
        end

        local x, y, z = table.unpack(GetEntityCoords(playerPed))
        local heading = GetEntityHeading(playerPed)

        local beerObject = CreateObject(beerModel, x, y, z, true, true, true)
        AttachEntityToEntity(beerObject, playerPed, GetPedBoneIndex(playerPed, 57005), 0.12, 0.08, 0.0, 160.0, 0.0, 180.0, true, true, false, true, 1, true)

        local animDuration = 3000 -- 3 seconds
        local animFlag = 49

        TaskPlayAnimAdvanced(playerPed, beerAnimDict, beerAnimName, x, y, z, 0.0, 0.0, heading, 1.0, 0.0, 0.0, animFlag, 1.0, 0, 0, 1.0)

        Citizen.Wait(animDuration)

        ClearPedSecondaryTask(playerPed)
        DeleteObject(beerObject)

        -- Add the beer effects here (if any)

        drinkingBeer = false
    else
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            multiline = true,
            args = {"Beer", "^2You're already drinking a beer."}
        })
    end
end, false)

function runAnim(anim)
	RequestAnimSet(anim)
	SetPedMovementClipset(GetPlayerPed(-1), anim, true)
end

function resetAnims()
	ResetPedMovementClipset(GetPlayerPed(-1))
	ResetPedWeaponMovementClipset(GetPlayerPed(-1))
	ResetPedStrafeClipset(GetPlayerPed(-1))
end