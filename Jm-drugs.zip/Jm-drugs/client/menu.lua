-----------------------------------------------------------
----              Menu by jman              ----
----                                                   ----
-----------------------------------------------------------

-- Creating a list to store the menu items.
local List = {}

-- Creating a menu pool.
_menuPool = NativeUI.CreatePool()

-- Creating the main menu.
mainMenu = NativeUI.CreateMenu("", "~b~Drug Menu", 1380, 0)
mainMenu:SetMenuWidthOffset(45)

-- Adding the main menu to the menu pool.
_menuPool:Add(mainMenu)

-- Creating a list for menu items.
List = {}

-- Looping through a list of drug-related props and adding them to the main menu.
for i, Prop in pairs(Config.Props) do
    name = Prop.name
    local propp = NativeUI.CreateItem(name, 'Place down a ~o~'..name)
    mainMenu:AddItem(propp)
    table.insert(List, Prop.spawncode)
end

-- Creating a "Remove Props" menu item.
local RemoveProps = NativeUI.CreateItem('~r~Remove Drugs', 'Remove the closest Drug Prop')
mainMenu:AddItem(RemoveProps)

-- Handling item selection in the main menu.
mainMenu.OnItemSelect = function(sender, item, index)
    if item == RemoveProps then
        -- Removing all drug props.
        for _, Prop in pairs(Config.Props) do
            DeleteProp(Prop.spawncode)
        end
    else
        -- Spawning a selected drug prop.
        SpawnProp(List[index])
    end
end

-- Refreshing the menu index.
_menuPool:RefreshIndex()

-- Creating a Citizen thread for menu controls.
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        _menuPool:MouseControlsEnabled(false)
        _menuPool:MouseEdgeEnabled(false)
        _menuPool:ControlDisablingEnabled(false)
        _menuPool:ProcessMenus()
        if IsControlJustPressed(1, Config.keybind) then
            -- Toggling the main menu's visibility.
            mainMenu:Visible(not mainMenu:Visible())
        end
    end
end)

-- Drug Prop Functions
-- Function to delete a specific prop.
function DeleteProp(Object)
    local Hash = GetHashKey(Object)
    local x, y, z = table.unpack(GetEntityCoords(PlayerPedId(), true))
    if DoesObjectOfTypeExistAtCoords(x, y, z, 1.5, Hash, true) then
        local Prop = GetClosestObjectOfType(x, y, z, 1.5, Hash, false, false, false)
        DeleteObject(Prop)
        Notify('~r~Drug Prop Removed!')
    end
end

-- Function to spawn a drug prop.
function SpawnProp(Object)
    local Player = PlayerPedId()
    local Coords = GetEntityCoords(Player)
    local Heading = GetEntityHeading(Player)

    -- Requesting the model for the prop and waiting until it's loaded.
    RequestModel(Object)
    while not HasModelLoaded(Object) do
        Citizen.Wait(0)
    end

    -- Creating the prop, positioning it, and making it non-collidable.
    local OffsetCoords = GetOffsetFromEntityInWorldCoords(Player, 0.0, 0.75, 0.0)
    local Prop = CreateObjectNoOffset(Object, OffsetCoords, false, true, false)
    SetEntityHeading(Prop, Heading)
    PlaceObjectOnGroundProperly(Prop)
    SetEntityCollision(Prop, false, true)
    SetEntityAlpha(Prop, 100)
    FreezeEntityPosition(Prop, true)
    SetModelAsNoLongerNeeded(Object)

    Notify('Press ~g~E ~w~to place\nPress ~r~R ~w~to cancel')

    -- Creating a thread for controlling the placement and deletion of the prop.
    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(0)

            local OffsetCoords = GetOffsetFromEntityInWorldCoords(Player, 0.0, 0.75, 0.0)
            local Heading = GetEntityHeading(Player)

            SetEntityCoordsNoOffset(Prop, OffsetCoords)
            SetEntityHeading(Prop, Heading)
            PlaceObjectOnGroundProperly(Prop)
            DisableControlAction(1, 38, true)
            DisableControlAction(1, 140, true)

            if IsDisabledControlJustPressed(1, 38) then
                -- Confirming placement.
                local PropCoords = GetEntityCoords(Prop)
                local PropHeading = GetEntityHeading(Prop)
                DeleteObject(Prop)

                RequestModel(Object)
                while not HasModelLoaded(Object) do
                    Citizen.Wait(0)
                end

                -- Recreating the prop at the confirmed position.
                local Prop = CreateObjectNoOffset(Object, PropCoords, true, true, true)
                SetEntityHeading(Prop, PropHeading)
                PlaceObjectOnGroundProperly(Prop)
                FreezeEntityPosition(Prop, true)
                SetEntityInvincible(Prop, true)
                SetModelAsNoLongerNeeded(Object)
                return
            end

            if IsDisabledControlJustPressed(1, 140) then
                -- Canceling placement.
                DeleteObject(Prop)
                return
            end
        end
    end)
end

-- Function to display a notification message.
function Notify(Text)
    SetNotificationTextEntry('STRING')
    AddTextComponentString(Text)
    DrawNotification(true, true)
end