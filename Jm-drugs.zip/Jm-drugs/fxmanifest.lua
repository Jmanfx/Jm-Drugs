--- Jman2 DS Development

fx_version 'bodacious'
game 'gta5'
lua54 "yes"
author 'Jmanfx AGD'

client_scripts {
    'client/NativeUI.lua',
    'config/config.lua',
    'client/menu.lua',
    "client/drug.lua"
}

escrow_ignore {
    'config/config.lua',  -- Only ignore one file
    'client/NativeUI.lua'
  }