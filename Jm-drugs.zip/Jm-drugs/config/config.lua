-- Jmanfx
Config = {}

Config.keybind = 57 -- Keybind for opening the drug menu ---- https://docs.fivem.net/docs/game-references/controls/

Config.Props = {
    {name = 'Drug Package', spawncode = 'prop_drug_package'},
    {name = 'Marajiuna Suitcase', spawncode = 'hei_prop_hei_drug_case'},
    {name = 'Cocaine Brick', spawncode = 'hei_prop_hei_drug_pack_01b'},
    {name = 'Pill container', spawncode = 'ng_proc_drug01a002'},
    {name = 'Weed Block', spawncode = 'prop_weed_block_01'},
    {name = 'Large Weed pallet', spawncode = 'prop_weed_pallet'},
    {name = 'Small weed plant', spawncode = 'prop_weed_02'},
    {name = 'Large Weed Plant', spawncode = 'prop_weed_01'},
    {name = 'Table', spawncode = 'prop_ven_market_table1'},
    {name = 'Extra Large Weed Pallet', spawncode = 'hei_prop_heist_weed_pallet_02'},
}

-- Add options for enabling/disabling overdose, killdrugs command, and duration of effects (in milliseconds)
Config.EnableOverdose = true -- Set to true to enable overdose
Config.EnableKillDrugsCommand = true -- Set to true to enable the "killdrugs" command
Config.WeedEffectDuration = 60 * 1000 -- Duration of weed effect (60 seconds)
Config.CokeEffectDuration = 40 * 1000 -- Duration of coke effect (40 seconds)
Config.MethEffectDuration = 80 * 1000 -- Duration of meth effect (80 seconds)
Config.LeanEffectDuration = 120 * 1000 -- Duration of lean effect (120 seconds)
Config.N2OEffectDuration = 5 * 1000 -- Duration of N2O effect (5 seconds)
